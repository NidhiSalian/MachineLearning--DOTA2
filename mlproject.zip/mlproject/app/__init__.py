from sklearn import metrics
import numpy as np
import pandas as pd
from sklearn.svm import SVC
from flask import Flask, render_template
from flask import request
#from app import app
import dota2api

app = Flask(__name__, static_url_path="/static", static_folder="static")
#from app import views

api = dota2api.Initialise("1851C397B623F65D6E88B692B8B27A8A")
@app.route('/')
@app.route('/index')


def index():
    heroes = api.get_heroes();
    hero_names = []
    for hero in heroes['heroes']:
          x = hero['localized_name']
          hero_names.append(x)
    return render_template("base.html", language='Python', lang=False, framework='Flask', hero_names = hero_names)

@app.route('/views', methods=['GET','POST'])

def views():
    heroes = api.get_heroes()
    r_id = []
    d_id = []
    hero_details = heroes['heroes']
    field1 = request.form['field1']
    field2 = request.form['field2']
    field3 = request.form['field3']
    field4 = request.form['field4']
    field5 = request.form['field5']
    field6 = request.form['field6']
    field7 = request.form['field7']
    field8 = request.form['field8']
    field9 = request.form['field9']
    field10 = request.form['field10']

    pics = []
    #print hero_details
    for hero in hero_details:
        hx = hero['localized_name']
        if hx == field1:
            r_id.append(hero['id'])
            if hero.get('url_full_portrait'):
                pics.append(hero.get('url_full_portrait'))
            elif hero.get('url_vertical_portrait'):
                pics.append(hero.get('url_vertical_portrait'))
            elif hero.get('url_large_portrait'):
                pics.append(hero.get('url_large_portrait'))
            elif hero.get('url_small_portrait'):
                pics.append(hero.get('url_small_portrait'))
            else:
                pics.append('No image found ')
        elif hx == field2:
            r_id.append(hero['id'])
            if hero.get('url_full_portrait'):
                pics.append(hero.get('url_full_portrait'))
            elif hero.get('url_vertical_portrait'):
                pics.append(hero.get('url_vertical_portrait'))
            elif hero.get('url_large_portrait'):
                pics.append(hero.get('url_large_portrait'))
            elif hero.get('url_small_portrait'):
                pics.append(hero.get('url_small_portrait'))
            else:
                pics.append('No image found ')
        elif hx == field3:
            r_id.append(hero['id'])
            if hero.get('url_full_portrait'):
                pics.append(hero.get('url_full_portrait'))
            elif hero.get('url_vertical_portrait'):
                pics.append(hero.get('url_vertical_portrait'))
            elif hero.get('url_large_portrait'):
                pics.append(hero.get('url_large_portrait'))
            elif hero.get('url_small_portrait'):
                pics.append(hero.get('url_small_portrait'))
            else:
                pics.append('No image found ')
        elif hx == field4:
            r_id.append(hero['id'])
            if hero.get('url_full_portrait'):
                pics.append(hero.get('url_full_portrait'))
            elif hero.get('url_vertical_portrait'):
                pics.append(hero.get('url_vertical_portrait'))
            elif hero.get('url_large_portrait'):
                pics.append(hero.get('url_large_portrait'))
            elif hero.get('url_small_portrait'):
                pics.append(hero.get('url_small_portrait'))
            else:
                pics.append('No image found ')
        elif hx == field5:
            r_id.append(hero['id'])
            if hero.get('url_full_portrait'):
                pics.append(hero.get('url_full_portrait'))
            elif hero.get('url_vertical_portrait'):
                pics.append(hero.get('url_vertical_portrait'))
            elif hero.get('url_large_portrait'):
                pics.append(hero.get('url_large_portrait'))
            elif hero.get('url_small_portrait'):
                pics.append(hero.get('url_small_portrait'))
            else:
                pics.append('No image found ')
        elif hx == field6:
            d_id.append(hero['id'])
            if hero.get('url_full_portrait'):
                pics.append(hero.get('url_full_portrait'))
            elif hero.get('url_vertical_portrait'):
                pics.append(hero.get('url_vertical_portrait'))
            elif hero.get('url_large_portrait'):
                pics.append(hero.get('url_large_portrait'))
            elif hero.get('url_small_portrait'):
                pics.append(hero.get('url_small_portrait'))
            else:
                pics.append('No image found ')
        elif hx == field7:
            d_id.append(hero['id'])
            if hero.get('url_full_portrait'):
                pics.append(hero.get('url_full_portrait'))
            elif hero.get('url_vertical_portrait'):
                pics.append(hero.get('url_vertical_portrait'))
            elif hero.get('url_large_portrait'):
                pics.append(hero.get('url_large_portrait'))
            elif hero.get('url_small_portrait'):
                pics.append(hero.get('url_small_portrait'))
            else:
                pics.append('No image found ')
        elif hx == field8:
            d_id.append(hero['id'])
            if hero.get('url_full_portrait'):
                pics.append(hero.get('url_full_portrait'))
            elif hero.get('url_vertical_portrait'):
                pics.append(hero.get('url_vertical_portrait'))
            elif hero.get('url_large_portrait'):
                pics.append(hero.get('url_large_portrait'))
            elif hero.get('url_small_portrait'):
                pics.append(hero.get('url_small_portrait'))
            else:
                pics.append('No image found ')
        elif hx == field9:
            d_id.append(hero['id'])
            if hero.get('url_full_portrait'):
                pics.append(hero.get('url_full_portrait'))
            elif hero.get('url_vertical_portrait'):
                pics.append(hero.get('url_vertical_portrait'))
            elif hero.get('url_large_portrait'):
                pics.append(hero.get('url_large_portrait'))
            elif hero.get('url_small_portrait'):
                pics.append(hero.get('url_small_portrait'))
            else:
                pics.append('No image found ')
        elif hx == field10:
            d_id.append(hero['id'])
            if hero.get('url_full_portrait'):
                pics.append(hero.get('url_full_portrait'))
            elif hero.get('url_vertical_portrait'):
                pics.append(hero.get('url_vertical_portrait'))
            elif hero.get('url_large_portrait'):
                pics.append(hero.get('url_large_portrait'))
            elif hero.get('url_small_portrait'):
                pics.append(hero.get('url_small_portrait'))
            else:
                pics.append('No image found ')
        else:
            continue
    print pics

    entry = []
    num_of_heroes = 114

    for i in range(1,num_of_heroes + 1):
        if i in r_id:
            entry.append(1)
        else:
            entry.append(0)
    for i in range(1, num_of_heroes + 1):
        if i in d_id:
            entry.append(1)
        else:
            entry.append(0)
    TRAIN_FNAME = 'C:\Users\MAHE\Documents\output.csv'

    train = pd.read_csv(TRAIN_FNAME,  index_col = False, skipinitialspace=True)
    X = np.matrix(train.iloc[:, 0:228])
    y = np.transpose(np.matrix(train.iloc[:, 228]))
    model = SVC( gamma = 0.001, C = 100, kernel = 'rbf', probability = True)
    model.fit(X,y)
    pred = model.predict(entry)
    print(pred)
    if pred == 1:
        team = "TEAM RADIANT"
    else:
        team = "TEAM DIRE"
    return render_template('predictpage.html', language='Python', lang=False, framework='Flask', field1 = field1, field2 = field2, field3 = field3,
                            field4 = field4, field5 = field5, field6 = field6, field7 = field7, field8 = field8, field9 = field9, field10 = field10,
                            pics = pics, team = team);


if __name__ ==  "__main__":
    app.run(debug=True)
