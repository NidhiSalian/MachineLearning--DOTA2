from flask import request, render_template
from app import app


@app.route('/views', methods=['GET','POST'])

def views():
    return render_template('predictpage.html', language='Python', lang=False, framework='Flask', field1 = field1);
